﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OnlineShop.Models.Products.Peripherals
{
    public abstract class Product : IProduct
    {
        private int id;
        private string manifacturer;
        private string model;
        private decimal price;
        private double overallPerformance;

        protected Product(int id,
            string manufacturer,
            string model,
            decimal price,
            double overallPerformance)
        {
            this.Id = id;
            this.Manufacturer = manufacturer;
            this.Model = model;
            this.Price = price;
            this.OverallPerformance = overallPerformance;
        }

        public int Id
        {
            get => this.id;
            private set
            {
                if (id <= 0)
                {
                    throw new AggregateException($"Id can not be less or equal than 0.");
                }
                this.id = value;
            }    
        }

        public string Manufacturer
        {
            get => this.manifacturer;
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new AggregateException($"Manufacturer can not be empty.");
                }
                this.manifacturer = value;
            }
        }

        public string Model
        {
            get => this.model;
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new AggregateException($"Model can not be empty.");
                }
                this.model = value;
            }
        }

        public virtual decimal Price
        {
            get => this.price;
            private set
            {
                if (price <= 0)
                {
                    throw new AggregateException($"Price can not be less or equal than 0.");
                }
                this.price = value;
            }
        }

        public virtual double OverallPerformance
        {
            get => this.overallPerformance;
            private set
            {
                if (overallPerformance <= 0)
                {
                    throw new AggregateException($"Overall Performance can not be less or equal than 0.");
                }
                this.overallPerformance = value;
            }
        }

        public override string ToString()
        {
            return $"Overall Performance: {overallPerformance}. Price: {price:F2} - {this.GetType().Name}: {manifacturer} {model} (Id: {id})";
        }
        
    }
}
