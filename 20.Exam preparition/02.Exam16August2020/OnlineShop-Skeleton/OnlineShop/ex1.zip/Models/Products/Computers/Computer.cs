﻿using OnlineShop.Models.Products.Components;
using OnlineShop.Models.Products.Peripherals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OnlineShop.Models.Products.Computers
{
    public abstract class Computer : Product, IComputer
    {
        private readonly ICollection<IComponent> components;
        private readonly ICollection<IPeripheral> peripherals;

        protected Computer(int id,
            string manufacturer,
            string model,
            decimal price,
            double overallPerformance)
            : base(id, manufacturer, model, price, overallPerformance)
        {
            components = new List<IComponent>();
            peripherals = new List<IPeripheral>();
        }

        public IReadOnlyCollection<IComponent> Components
            => (IReadOnlyCollection<IComponent>)components;

        public IReadOnlyCollection<IPeripheral> Peripherals
            => (IReadOnlyCollection<IPeripheral>)peripherals;

        public void AddComponent(IComponent component)
        {
            IComponent currComponent = components.FirstOrDefault(x => x.GetType().Name == component.GetType().Name);
            if (currComponent != null)
            {
                throw new AggregateException($"Component {currComponent.GetType().Name} already exists in {this.GetType().Name} with Id {component.Id}.");
            }
            components.Add(component);
        }

        public void AddPeripheral(IPeripheral peripheral)
        {
            IPeripheral currPer = peripherals.FirstOrDefault(x => x.GetType().Name == peripheral.GetType().Name);
            if (currPer != null)
            {
                throw new AggregateException($"Peripheral {peripheral.GetType().Name} already exists in {this.GetType().Name} with Id {peripheral.Id}.");
            }
            peripherals.Add(peripheral);
        }

        public IComponent RemoveComponent(string componentType)
        {
            if (!(components.Any(c => c.GetType().Name == componentType) || components.Count == 0))
            {
                throw new ArgumentException($"Component {componentType} does not exist in {this.GetType().Name} with Id {this.Id}.");
            }
            IComponent removerComponent = components.FirstOrDefault(x => x.GetType().Name == componentType);
            components.Remove(removerComponent);
            return removerComponent;
        }

        public IPeripheral RemovePeripheral(string peripheralType)
        {
            if (!(peripherals.Any(c => c.GetType().Name == peripheralType) || peripherals.Count == 0))
            {
                throw new ArgumentException($"Peripheral {peripheralType} does not exist in {this.GetType().Name} with Id {this.Id}.");
            }
            IPeripheral removerPer = peripherals.FirstOrDefault(x => x.GetType().Name == peripheralType);
            peripherals.Remove(removerPer);
            return removerPer;
        }

        public override double OverallPerformance
            => this.components.Count == 0 ? base.OverallPerformance : base.OverallPerformance + components.Average(x => x.OverallPerformance);
        public override decimal Price
            => base.Price + components.Sum(x => x.Price) + peripherals.Sum(y => y.Price);

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Overall Performance: {OverallPerformance}. Price: {Price} - {this.GetType().Name}: {Manufacturer} {Model} (Id: {Id})");
            sb.AppendLine($" Components ({components.Count}):");
            foreach (var component in components)
            {
                sb.AppendLine($"  {component}");
            }
            sb.AppendLine($" Peripherals ({peripherals.Count}); Average Overall Performance ({peripherals.Average(x => x.OverallPerformance):F2}):");
            foreach (var peripheral in peripherals)
            {
                sb.AppendLine($"  {peripheral}");
            }

            return sb.ToString().TrimEnd();
        }
    }
}
