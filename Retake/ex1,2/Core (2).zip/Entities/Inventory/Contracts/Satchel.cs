﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WarCroft.Entities.Inventory.Contracts
{
    public class Satchel : Bag
    {
        public Satchel()
            :base(20)
        {

        }
    }
}
