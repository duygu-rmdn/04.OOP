﻿using Bakery.Core.Contracts;
using Bakery.Models.BakedFoods;
using Bakery.Models.BakedFoods.Contracts;
using Bakery.Models.Drinks;
using Bakery.Models.Drinks.Contracts;
using Bakery.Models.Tables.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace Bakery.Core
{
    //class Controller : IController
    //{
    //    private List<IBakedFood> foods;
    //    private List<IDrink> drinks;
    //    private List<ITable> table;

    //    public string AddDrink(string type, string name, int portion, string brand)
    //    {
    //        Drink bakedFood = null;
    //        if (type == "Tea")
    //        {
    //            bakedFood = new Tea(name, price);
    //        }
    //        else if (type == "Water")
    //        {
    //            bakedFood = new Cake(name, price);
    //        }
    //        foods.Add(bakedFood);
    //        return $"Added {name} ({type}) to the menu";

    //    }

    //    public string AddFood(string type, string name, decimal price)
    //    {
    //        BakedFood bakedFood = null;
    //        if (type == "Bread")
    //        {
    //            bakedFood = new Bread(name, price);
    //        }
    //        else if (type == "Cake")
    //        {
    //            bakedFood = new Cake(name, price);
    //        }
    //        foods.Add(bakedFood);
    //        return $"Added {name} ({type}) to the menu";
    //    }

    //    public string AddTable(string type, int tableNumber, int capacity)
    //    {
    //        throw new NotImplementedException();
    //    }

    //    public string GetFreeTablesInfo()
    //    {
    //        throw new NotImplementedException();
    //    }

    //    public string GetTotalIncome()
    //    {
    //        throw new NotImplementedException();
    //    }

    //    public string LeaveTable(int tableNumber)
    //    {
    //        throw new NotImplementedException();
    //    }

    //    public string OrderDrink(int tableNumber, string drinkName, string drinkBrand)
    //    {
    //        throw new NotImplementedException();
    //    }

    //    public string OrderFood(int tableNumber, string foodName)
    //    {
    //        throw new NotImplementedException();
    //    }

    //    public string ReserveTable(int numberOfPeople)
    //    {
    //        throw new NotImplementedException();
    //    }
    //}
}
