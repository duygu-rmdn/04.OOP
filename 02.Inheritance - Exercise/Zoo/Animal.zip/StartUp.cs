﻿namespace Zoo
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Bear b = new Bear("sadfafa");
            System.Console.WriteLine(b);
        }
    }
}