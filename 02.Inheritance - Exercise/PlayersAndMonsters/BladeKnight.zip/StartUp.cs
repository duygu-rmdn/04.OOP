﻿using System;

namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            BladeKnight b = new BladeKnight("dssds", 123);
            Console.WriteLine(b);
        }
    }
}