﻿using _03._Shopping_Spree.Core;
using System;

namespace _03._Shopping_Spree
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Engine engin = new Engine();
            engin.Run();
        }
    }
}
