﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03._Shopping_Spree.Common
{
    public static class ClobalConstants
    {
        public const string EMPY_NAME_EXP_MESS = "Name cannot be empty";
        public const string NEGATIVE_MONEY_EXP_MESS = "Money cannot be negative";
    }
}
