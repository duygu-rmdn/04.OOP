﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03._Telephony.Core.Contacts
{
    public interface IReader
    {
        public string ReadLine();
    }
}
