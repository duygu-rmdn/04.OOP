﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03._Telephony.Models.Contacts
{
    public interface IBrowseble
    {
         public string Browse(string url);
    }
}
