﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03._Telephony.Models.Contacts
{
    public interface ICalable
    {
         public string Call(string number);
        
    }
}
